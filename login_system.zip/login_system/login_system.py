# User Login System
greet = print("Hello User 2.0, Enter your info to check out your data.")
attempts = 0
max_attempts = 3
while attempts < max_attempts:
    user_name = input("Enter your name (or type 'exit' to quit):")
    if user_name.lower() == 'exit':
        print("Goodbye!")
        break
    user_id = input("Enter your ID: ")
    user_password = input("Enter your password: ")

    if user_name == "GRA-1" and user_id == "001" and user_password == "gra_01":
        print(f"Welcome {user_name}, Check out your details.")
        GRA_1 = {
            "Name" : "Hanry",
            "Age"  : "25",
            "Nationality" :"American",
            "Profession" : "Software Developer",
            "Workplace" : "Google",
            "Salary" : "$150,000"
        }
        print(GRA_1)
        break

    elif user_name == "MAYA-1" and user_id == "011" and user_password == "maya@03":
        print(f"Welcome {user_name}, Check out your details,")
        MAYA_1 = {
            "Name" : "Antony",
            "Age"  : "32",
            "Nationality" :"British",
            "Profession" : "AI Engineer",
            "Workplace" : "Meta",
            "Salary" : "$210,000"
        }
        print(MAYA_1)
        break
    else:
        attempts += 1
        remaining = max_attempts - attempts
        if remaining > 0:
            print(f"Invalid User. {remaining} attempts remaining.")
        else:
            print("Too many failed attempts. Access denied.")